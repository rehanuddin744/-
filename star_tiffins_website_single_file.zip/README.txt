Star Tiffins website — single-file version

All six supplied food photos are embedded directly inside index.html. No separate images folder is needed. Upload only index.html to your GitHub repository.
